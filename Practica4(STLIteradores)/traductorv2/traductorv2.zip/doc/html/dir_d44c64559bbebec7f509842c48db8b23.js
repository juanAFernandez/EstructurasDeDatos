var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "doc.h", "doc_8h_source.html", null ],
    [ "Palabra.h", "Palabra_8h.html", [
      [ "Palabra", "classPalabra.html", "classPalabra" ],
      [ "iterator", "classPalabra_1_1iterator.html", "classPalabra_1_1iterator" ],
      [ "const_iterator", "classPalabra_1_1const__iterator.html", "classPalabra_1_1const__iterator" ]
    ] ],
    [ "Traductor.h", "Traductor_8h.html", [
      [ "Traductor", "classTraductor.html", "classTraductor" ],
      [ "iterator", "classTraductor_1_1iterator.html", "classTraductor_1_1iterator" ],
      [ "const_iterator", "classTraductor_1_1const__iterator.html", "classTraductor_1_1const__iterator" ]
    ] ]
];