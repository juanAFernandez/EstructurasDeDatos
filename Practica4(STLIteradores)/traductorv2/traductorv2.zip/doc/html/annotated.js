var annotated =
[
    [ "Palabra", "classPalabra.html", "classPalabra" ],
    [ "Traductor", "classTraductor.html", "classTraductor" ]
];