var classTraductor_1_1iterator =
[
    [ "operator!=", "classTraductor_1_1iterator.html#adb42a1373617d72f773d9fefa3a0ec9a", null ],
    [ "operator*", "classTraductor_1_1iterator.html#a4990911aa7cafad4822ab8c26e995710", null ],
    [ "operator++", "classTraductor_1_1iterator.html#a580938c4aa23a1c201cc95d8587c87f4", null ],
    [ "operator->", "classTraductor_1_1iterator.html#a9b999945187cb876e4ba90e8e8d744ba", null ],
    [ "operator=", "classTraductor_1_1iterator.html#a0235939b8d94ee9192a87c91f9e26574", null ],
    [ "puntero", "classTraductor_1_1iterator.html#a03d323d0d77a0d98096671a8936753a3", null ]
];