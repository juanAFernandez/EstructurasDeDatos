var classTraductor =
[
    [ "const_iterator", "classTraductor_1_1const__iterator.html", "classTraductor_1_1const__iterator" ],
    [ "iterator", "classTraductor_1_1iterator.html", "classTraductor_1_1iterator" ],
    [ "Traductor", "classTraductor.html#a9723a49b5b82689bff2b827ca2da3f45", null ],
    [ "addPalabra", "classTraductor.html#a927e70a061b954e22e9f02f7e3ca38bb", null ],
    [ "begin", "classTraductor.html#a8579dcfda2e226c22af50901689f1805", null ],
    [ "begin", "classTraductor.html#a79dacb400c9aa1444f49fdaa0bf138b9", null ],
    [ "buscarPalabra", "classTraductor.html#a391755e1f4c125aaca092709e7eacca2", null ],
    [ "cargaTraductor", "classTraductor.html#ae48ccde85eb81d3daa4db401b08ac8d8", null ],
    [ "end", "classTraductor.html#a3bdc6eef3194e812adf180821c287655", null ],
    [ "end", "classTraductor.html#a5b07a92b917da1f843c2283d586fa6f3", null ],
    [ "getNumeroPalabras", "classTraductor.html#aa77fe0623d30081c6f54548e006ee2f1", null ],
    [ "getTraduccion", "classTraductor.html#a04031bba25ffd393933af00c06cb312d", null ],
    [ "getTraducciones", "classTraductor.html#a81468e7956bd098c8bac489bd374b31c", null ],
    [ "split", "classTraductor.html#af6e75f7bd93eb4e8b69afa20cbc5ad00", null ],
    [ "operator>>", "classTraductor.html#acafcfc537c7749b1fa25104ba2ed7e9f", null ],
    [ "palabras", "classTraductor.html#a6ff738fc5415656ed3c98282354823be", null ]
];