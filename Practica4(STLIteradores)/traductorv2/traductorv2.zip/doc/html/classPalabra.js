var classPalabra =
[
    [ "const_iterator", "classPalabra_1_1const__iterator.html", "classPalabra_1_1const__iterator" ],
    [ "iterator", "classPalabra_1_1iterator.html", "classPalabra_1_1iterator" ],
    [ "Palabra", "classPalabra.html#a8e74f02e148cdcb5bb91bc2ae193183e", null ],
    [ "addPalabraDestino", "classPalabra.html#ace6585d9142cc3d424b4d2dfdd0d84b7", null ],
    [ "begin", "classPalabra.html#aff17fc8ba18b2fb558be5d2d0cf25543", null ],
    [ "begin", "classPalabra.html#a70d9f9605363bff25d72617e24225e31", null ],
    [ "end", "classPalabra.html#abe09d31e3a9310f462eb839529e3a15f", null ],
    [ "end", "classPalabra.html#a1c77f72fe6a9915ba61ed99d0691823d", null ],
    [ "getNumeroPalabrasDestino", "classPalabra.html#a4ae1a0425b72ab14a252fa1d4fc3b310", null ],
    [ "getPalabraOrigen", "classPalabra.html#a592db4c77b00c459bfd28902e5858127", null ],
    [ "getPalabrasDestino", "classPalabra.html#ad55676ec4a82883c210b4738b014a596", null ],
    [ "imprimePalabra", "classPalabra.html#a4b6549dede3d8f35195f522cfcbe3b9f", null ],
    [ "saluda", "classPalabra.html#a86aab963b1958449ed4050e5f3d63c3d", null ],
    [ "setPalabraOrigen", "classPalabra.html#a038e441d1518188a61c6502e7bda08e5", null ],
    [ "palabra", "classPalabra.html#a52492db15e6afa0b81428806f75f2a7a", null ]
];