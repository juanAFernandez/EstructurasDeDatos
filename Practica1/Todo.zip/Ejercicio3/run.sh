g++ ejercicio_desc.cpp -o ejercicioDesconocido
./ejercicioDesconocido 10
