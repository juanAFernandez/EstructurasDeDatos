var classTraductor =
[
    [ "Traductor", "classTraductor.html#a9723a49b5b82689bff2b827ca2da3f45", null ],
    [ "addPalabra", "classTraductor.html#a927e70a061b954e22e9f02f7e3ca38bb", null ],
    [ "cargaTraductor", "classTraductor.html#ae48ccde85eb81d3daa4db401b08ac8d8", null ],
    [ "getNumeroPalabras", "classTraductor.html#aa77fe0623d30081c6f54548e006ee2f1", null ],
    [ "getTraduccion", "classTraductor.html#a04031bba25ffd393933af00c06cb312d", null ],
    [ "getTraducciones", "classTraductor.html#a81468e7956bd098c8bac489bd374b31c", null ],
    [ "split", "classTraductor.html#af6e75f7bd93eb4e8b69afa20cbc5ad00", null ],
    [ "operator>>", "classTraductor.html#acafcfc537c7749b1fa25104ba2ed7e9f", null ],
    [ "numPalabras", "classTraductor.html#a9b331936e99039f1f9073d3de0021149", null ],
    [ "palabras", "classTraductor.html#a3031b1a8804fd5ed5a25e6363034a199", null ]
];