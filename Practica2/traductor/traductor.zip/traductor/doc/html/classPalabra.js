var classPalabra =
[
    [ "Palabra", "classPalabra.html#a8e74f02e148cdcb5bb91bc2ae193183e", null ],
    [ "addPalabraDestino", "classPalabra.html#ace6585d9142cc3d424b4d2dfdd0d84b7", null ],
    [ "getPalabraOrigen", "classPalabra.html#a592db4c77b00c459bfd28902e5858127", null ],
    [ "getPalabrasDestino", "classPalabra.html#ad55676ec4a82883c210b4738b014a596", null ],
    [ "setPalabraOrigen", "classPalabra.html#a038e441d1518188a61c6502e7bda08e5", null ],
    [ "numPalabrasDestino", "classPalabra.html#ad221fc5592a353c5fc38fce175bc0cc1", null ],
    [ "palabraOrigen", "classPalabra.html#a606555ac42fabb5fe3d8b58b7466c1d9", null ],
    [ "palabrasDestino", "classPalabra.html#abbfe423891fd0b9ebf34481e0d4a03ba", null ]
];