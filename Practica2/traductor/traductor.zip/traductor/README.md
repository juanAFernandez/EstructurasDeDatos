Para compilar ejecutar: > make
Para construir documentacion: > make documentacion
	Entrada a la documentación en doc/html/index.html
Para correr traductor: > make runTraductor
	Ejecuta el traductor con el fichero de palabras por defecto, español->inglés
