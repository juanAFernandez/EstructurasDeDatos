var searchData=
[
  ['getnumeropalabras',['getNumeroPalabras',['../class_traductor.html#aa77fe0623d30081c6f54548e006ee2f1',1,'Traductor']]],
  ['getpalabraorigen',['getPalabraOrigen',['../class_palabra.html#a592db4c77b00c459bfd28902e5858127',1,'Palabra']]],
  ['gettraducciones',['getTraducciones',['../class_traductor.html#ae5523d25e1a5365a4393305cc0107eb3',1,'Traductor']]],
  ['gettraduccionesdestino',['getTraduccionesDestino',['../class_palabra.html#a73d00ee2958664173d9065aeac6d89cf',1,'Palabra']]]
];
