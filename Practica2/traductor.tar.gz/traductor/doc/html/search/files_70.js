var searchData=
[
  ['palabra_2ecpp',['palabra.cpp',['../palabra_8cpp.html',1,'']]],
  ['palabra_2eh',['palabra.h',['../palabra_8h.html',1,'']]],
  ['pruebatraductor_2ecpp',['pruebatraductor.cpp',['../pruebatraductor_8cpp.html',1,'']]]
];
