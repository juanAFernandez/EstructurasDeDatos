var searchData=
[
  ['numerotraducciones',['numeroTraducciones',['../class_palabra.html#a149a486365a570277dcbe7ec677d03a4',1,'Palabra']]]
];
