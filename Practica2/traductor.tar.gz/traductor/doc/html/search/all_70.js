var searchData=
[
  ['palabra',['Palabra',['../class_palabra.html',1,'Palabra'],['../class_palabra.html#a8e74f02e148cdcb5bb91bc2ae193183e',1,'Palabra::Palabra()']]],
  ['palabra_2ecpp',['palabra.cpp',['../palabra_8cpp.html',1,'']]],
  ['palabra_2eh',['palabra.h',['../palabra_8h.html',1,'']]],
  ['pospalabra',['posPalabra',['../class_traductor.html#a04351184344ebbb0b9e5d7ecbbdcff29',1,'Traductor']]],
  ['pruebatraductor_2ecpp',['pruebatraductor.cpp',['../pruebatraductor_8cpp.html',1,'']]]
];
