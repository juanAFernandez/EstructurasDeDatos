var searchData=
[
  ['operator_3e_3e',['operator>>',['../class_traductor.html#a6bf7dd22b4c96499cd26853d589a3ffa',1,'Traductor::operator&gt;&gt;()'],['../traductor_8cpp.html#a6bf7dd22b4c96499cd26853d589a3ffa',1,'operator&gt;&gt;():&#160;traductor.cpp']]]
];
