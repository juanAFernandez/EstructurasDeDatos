var searchData=
[
  ['palabra',['Palabra',['../class_palabra.html',1,'']]]
];
