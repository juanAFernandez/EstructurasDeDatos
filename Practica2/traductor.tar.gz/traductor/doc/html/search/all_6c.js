var searchData=
[
  ['load',['load',['../class_palabra.html#afb7bd4c427f142a851bf306ddc8e991c',1,'Palabra']]],
  ['loadtraducciones',['loadTraducciones',['../class_traductor.html#a3fa33f9e42d812bc6e146e479be7101b',1,'Traductor']]]
];
