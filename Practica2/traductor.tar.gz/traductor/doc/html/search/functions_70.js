var searchData=
[
  ['palabra',['Palabra',['../class_palabra.html#a8e74f02e148cdcb5bb91bc2ae193183e',1,'Palabra']]],
  ['pospalabra',['posPalabra',['../class_traductor.html#a04351184344ebbb0b9e5d7ecbbdcff29',1,'Traductor']]]
];
