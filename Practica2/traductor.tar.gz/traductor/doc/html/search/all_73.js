var searchData=
[
  ['setpalabra',['setPalabra',['../class_palabra.html#a929259205dcad406f44a313970cd7c7f',1,'Palabra']]]
];
