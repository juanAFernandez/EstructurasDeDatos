var classListaT =
[
    [ "Celda", "structListaT_1_1Celda.html", "structListaT_1_1Celda" ],
    [ "ListaT", "classListaT.html#a567ed7dd362449bf702799c11cd9fb2a", null ],
    [ "delUltimo", "classListaT.html#a9099651c18f0231f920532aca328ab27", null ],
    [ "getNumeroElementos", "classListaT.html#a600c40348d5f971550a2147b02c1517c", null ],
    [ "getUltimo", "classListaT.html#a2da4f3782e11382f6bc41e6c96f9477e", null ],
    [ "imprimeLista", "classListaT.html#a4137ae14140d667967d44a1cd9a06d6d", null ],
    [ "insertarAlFinal", "classListaT.html#a89514cb698f0fbaa498f99f17e6caf52", null ],
    [ "insertarAlPrincipio", "classListaT.html#a07e34703fe06bfb358342dd1038a4acd", null ],
    [ "vacia", "classListaT.html#aa89457f0107bc63d6cb882721f8ec8c8", null ],
    [ "cabecera", "classListaT.html#a9b19b75f8122ec9455f3a802399184c8", null ],
    [ "numElementos", "classListaT.html#a59b4d061f71cdbbf861ac5b89f3a7d06", null ]
];