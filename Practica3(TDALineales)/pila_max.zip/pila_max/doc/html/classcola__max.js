var classcola__max =
[
    [ "getNumeroElementos", "classcola__max.html#aab72e5444cd7ba8b04ba35a50e638093", null ],
    [ "inicio", "classcola__max.html#a89df5dd70ee8d8eeaf0187a56671f76f", null ],
    [ "invertirPila", "classcola__max.html#a1bbf4cbe935d3f9fd1d13b44e6c7a184", null ],
    [ "poner", "classcola__max.html#af3d5aa7d5cd4b99dc54882d34884ec79", null ],
    [ "quitar", "classcola__max.html#a08669c970f917d3a711f3faf2709ca8d", null ],
    [ "vacia", "classcola__max.html#ae7d8a164394773f287a3c56e3024c654", null ],
    [ "pilaElementos", "classcola__max.html#a6cbf99d2d400f2e89a95e25ad6dcfbbd", null ]
];