var classpila__max__lista =
[
    [ "poner", "classpila__max__lista.html#ab2ea0f0d1dbe9d54cb66128a479d34d8", null ],
    [ "quitar", "classpila__max__lista.html#a5409e2c589fe4c11eb1464c469a43b35", null ],
    [ "tope", "classpila__max__lista.html#ae1e109d6f19668364021296677431ea2", null ],
    [ "vacia", "classpila__max__lista.html#a64eb92323eeeb2f6122f30d7b092faa8", null ],
    [ "listaElementos", "classpila__max__lista.html#a5bcf6cdb3d27b7028380e20f75588aaa", null ]
];