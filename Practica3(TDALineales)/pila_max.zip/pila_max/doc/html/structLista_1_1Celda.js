var structLista_1_1Celda =
[
    [ "elemento", "structLista_1_1Celda.html#a88ff43dabe8b196a5103d770163ac277", null ],
    [ "siguiente", "structLista_1_1Celda.html#ac6b93477f9e33731947c802bce988572", null ]
];