var structListaT_1_1Celda =
[
    [ "elemento", "structListaT_1_1Celda.html#a298f1853939e248d84a06458a607829b", null ],
    [ "siguiente", "structListaT_1_1Celda.html#a36e5f237f7e7a8bc7414cdd6293da7d3", null ]
];