var classLista =
[
    [ "Celda", "structLista_1_1Celda.html", "structLista_1_1Celda" ],
    [ "Lista", "classLista.html#a1f668b36909182ef1360b48503529a31", null ],
    [ "getNumeroElementos", "classLista.html#ad1335962d501aef607f63847b5a676cf", null ],
    [ "imprimeLista", "classLista.html#a0e18270a6074f20156161fa30c3469a9", null ],
    [ "insertarAlFinal", "classLista.html#aa3b68fbd27e092434eb12b149c41ccc2", null ],
    [ "insertarAlPrincipio", "classLista.html#a0dc0ba1801803b54662ac6a7d00616aa", null ],
    [ "cabecera", "classLista.html#a3a8e4a0637c6c328a00acc4b186f34a2", null ],
    [ "numElementos", "classLista.html#a104b67f34192361708ae5e4304e9bcb0", null ]
];