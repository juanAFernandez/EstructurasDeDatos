var classPila =
[
    [ "getNumeroElementos", "classPila.html#af128cb52fbcbb9c2f4c29dc85b64d69e", null ],
    [ "poner", "classPila.html#abc2b8c2fc99f5f750510cf9ce96a7ba4", null ],
    [ "quitar", "classPila.html#a7eb7aca18dffbc1d570195de1e446054", null ],
    [ "tope", "classPila.html#a136c5e27ef8aaa5106b87e9dbae5c507", null ],
    [ "vacia", "classPila.html#aa74bc3c698e94380d5f69bd24b910354", null ],
    [ "pila", "classPila.html#a9b6c14574bc7dfb7553b6bb3f9b2daae", null ]
];