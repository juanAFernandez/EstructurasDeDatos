var annotated =
[
    [ "Cola", "classCola.html", "classCola" ],
    [ "cola_max", "classcola__max.html", "classcola__max" ],
    [ "elemento", "structelemento.html", "structelemento" ],
    [ "Lista", "classLista.html", "classLista" ],
    [ "ListaT", "classListaT.html", "classListaT" ],
    [ "Pila", "classPila.html", "classPila" ],
    [ "pila_max_cola", "classpila__max__cola.html", "classpila__max__cola" ],
    [ "pila_max_lista", "classpila__max__lista.html", "classpila__max__lista" ],
    [ "pila_max_vd", "classpila__max__vd.html", "classpila__max__vd" ],
    [ "Vector", "classVector.html", "classVector" ],
    [ "VectorT", "classVectorT.html", "classVectorT" ]
];