var classCola =
[
    [ "Celda", "structCola_1_1Celda.html", "structCola_1_1Celda" ],
    [ "Cola", "classCola.html#aea3a971c7c522618f4dc972e8b4ff153", null ],
    [ "Cola", "classCola.html#a2249ab5603a92fddb8bd9bb55abeaa24", null ],
    [ "~Cola", "classCola.html#af4d55930921c93c626006ba2e842530b", null ],
    [ "frente", "classCola.html#a1df4ad2b50116ef22e77ad3f77b02d29", null ],
    [ "frente", "classCola.html#a79aa911410e9698d255cb00acee7b365", null ],
    [ "num_elementos", "classCola.html#aa8654a248be63133bacdc2e0e102f814", null ],
    [ "operator=", "classCola.html#a2ac480681dec95b8ffeea075507849e2", null ],
    [ "poner", "classCola.html#a4a902e5805ae74f8d80c6f3267fd14c4", null ],
    [ "quitar", "classCola.html#a320766ddc7020424052c99e5c82a105d", null ],
    [ "vacia", "classCola.html#a63d527f52e207cd6783f12df481ad175", null ],
    [ "num_elem", "classCola.html#aba9d5dd07641ceda78b84f1929cde0f4", null ],
    [ "primera", "classCola.html#a0f332c0bfe8206335b94491cf63aaa67", null ],
    [ "ultima", "classCola.html#af25f40617cc0430aab121898486a6d8d", null ]
];