var classpila__max__cola =
[
    [ "invertirCola", "classpila__max__cola.html#add62b3c65a1bace93f14be10fb28d489", null ],
    [ "poner", "classpila__max__cola.html#a800dedfc16a056ffc415d29ef3af572e", null ],
    [ "quitar", "classpila__max__cola.html#af51be909f11734dacfe2a87d2e21a41d", null ],
    [ "tope", "classpila__max__cola.html#afd3dbab2dc7134d6c415829cbc834ea2", null ],
    [ "vacia", "classpila__max__cola.html#aaa2e5ab608ac412cc95a46b83837ce04", null ],
    [ "colaElementos", "classpila__max__cola.html#a00308027a3c3fb38e4caf4e7a95a21e9", null ]
];