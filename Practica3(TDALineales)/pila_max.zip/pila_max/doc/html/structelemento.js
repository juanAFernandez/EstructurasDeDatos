var structelemento =
[
    [ "operator<<", "structelemento.html#add9d7e8b569d02e1e20f1b7bc52553f7", null ],
    [ "operator<<", "structelemento.html#add9d7e8b569d02e1e20f1b7bc52553f7", null ],
    [ "operator<<", "structelemento.html#add9d7e8b569d02e1e20f1b7bc52553f7", null ],
    [ "operator<<", "structelemento.html#add9d7e8b569d02e1e20f1b7bc52553f7", null ],
    [ "entero", "structelemento.html#a1a35d81697b20401a0eb5afafd71a5af", null ],
    [ "maximoPila", "structelemento.html#a7656fd92ae6bae728dcbc4e37a7e7127", null ]
];