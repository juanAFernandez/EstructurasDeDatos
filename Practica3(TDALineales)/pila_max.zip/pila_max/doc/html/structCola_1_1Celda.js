var structCola_1_1Celda =
[
    [ "Celda", "structCola_1_1Celda.html#a1ae66a8f4dad33d2bc811f0ac13150b9", null ],
    [ "Celda", "structCola_1_1Celda.html#a5a9b9c79bfac971bdaab7eaa49d68bf9", null ],
    [ "elemento", "structCola_1_1Celda.html#af84ab659f7018e350c890fc6abb8a338", null ],
    [ "siguiente", "structCola_1_1Celda.html#a7c389dfd00b09d44632a6d179c79961b", null ]
];